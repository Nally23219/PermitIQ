const express = require("express");
const cors = require("cors");
const Anthropic = require("@anthropic-ai/sdk");
const multer = require("multer");
const pdfParse = require("pdf-parse");
const path = require("path");

require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 3001;

// In production, serve React build from same origin — CORS only needed in dev
app.use(cors({
  origin: process.env.NODE_ENV === "production"
    ? false
    : ["http://localhost:3000", "http://localhost:5173"],
}));

app.use(express.json({ limit: "10mb" }));

// File upload — memory storage, 20MB limit
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 20 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowed = [
      "application/pdf",
      "text/plain",
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/webp",
    ];
    cb(null, allowed.includes(file.mimetype));
  },
});

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

// ── Extract text from uploaded file ──────────────────────────────────────────
async function extractFileText(file) {
  if (!file) return "";

  if (file.mimetype === "application/pdf") {
    try {
      const data = await pdfParse(file.buffer);
      return (data.text || "").trim();
    } catch (err) {
      console.error("PDF parse error:", err.message);
      return "";
    }
  }

  if (file.mimetype === "text/plain") {
    return file.buffer.toString("utf-8").trim();
  }

  // Images — return base64 for vision API
  return null; // handled separately below
}

// ── Build message content for Claude ─────────────────────────────────────────
async function buildMessages(files, textFields) {
  const content = [];

  // Process each file
  for (const file of files || []) {
    if (file.mimetype === "application/pdf" || file.mimetype === "text/plain") {
      const text = await extractFileText(file);
      if (text && text.length > 10) {
        content.push({
          type: "text",
          text: `--- Uploaded file: ${file.originalname} ---\n${text}`,
        });
      } else {
        content.push({
          type: "text",
          text: `--- Uploaded file: ${file.originalname} (no extractable text — scanned document) ---`,
        });
      }
    } else if (file.mimetype.startsWith("image/")) {
      // Send image directly to Claude vision
      const base64 = file.buffer.toString("base64");
      content.push({
        type: "image",
        source: {
          type: "base64",
          media_type: file.mimetype,
          data: base64,
        },
      });
    }
  }

  // Add text fields
  const textParts = Object.entries(textFields || {})
    .filter(([, v]) => v && v.trim())
    .map(([k, v]) => `${k}: ${v.trim()}`);

  if (textParts.length > 0) {
    content.push({ type: "text", text: textParts.join("\n") });
  }

  return content;
}

// ── POST /api/analyze-plans ───────────────────────────────────────────────────
app.post(
  "/api/analyze-plans",
  upload.array("files", 5),
  async (req, res) => {
    try {
      const { neighborhood, propertyType, description } = req.body;

      const systemPrompt = `You are PermitIQ, an expert Boston zoning and building permit advisor with deep knowledge of the Boston Zoning Code, 780 CMR (Massachusetts State Building Code), and ZBA procedures.

Analyze the submitted construction or addition plans and respond with EXACTLY these bold section headers:

**PROJECT SUMMARY**
What the project is based on what was provided.

**ZONING COMPLIANCE CHECK**
Check each — state Compliant, Non-Compliant, or Unknown:
- FAR (Floor Area Ratio)
- Front setback
- Side yard setbacks
- Rear setback
- Building height
- Lot coverage
- Parking
- Use / permitted as-of-right

**VARIANCES REQUIRED**
Every variance or special permit needed. For each: the violation, the specific Boston Zoning Code article, and the dimensional standard. If none needed, say so clearly.

**ZBA ACTION PLAN**
Numbered step-by-step plan. Include the 45-day filing deadline rule, fees ($150 flat for residential 3 units or fewer; $150 per violation for all others), and permitsonline.boston.gov.

**HARDSHIP ARGUMENTS**
Strongest legal arguments for each variance under Massachusetts variance law (unique hardship, not self-created, in the public interest).

**DOCUMENTS TO PREPARE**
Complete bulleted checklist for a successful ZBA filing.

**RISK ASSESSMENT**
Honest likelihood of ZBA approval, what could derail it, any redesign that would eliminate variances.`;

      const fileContent = await buildMessages(req.files, {
        "Neighborhood": neighborhood,
        "Property type": propertyType,
        "Project description": description,
      });

      if (!fileContent.length) {
        return res.status(400).json({ error: "No content provided. Upload plans or add a project description." });
      }

      fileContent.push({
        type: "text",
        text: "\nAnalyze this project for all variances needed and provide a complete ZBA action plan.",
      });

      const message = await client.messages.create({
        model: "claude-sonnet-4",
        max_tokens: 4096,
        system: systemPrompt,
        messages: [{ role: "user", content: fileContent }],
      });

      const text = message.content
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("")
        .trim();

      res.json({ result: text });
    } catch (err) {
      console.error("analyze-plans error:", err);
      res.status(500).json({ error: err.message || "Analysis failed" });
    }
  }
);

// ── POST /api/analyze-denial ──────────────────────────────────────────────────
app.post(
  "/api/analyze-denial",
  upload.fields([
    { name: "denialFiles", maxCount: 2 },
    { name: "planFiles", maxCount: 5 },
  ]),
  async (req, res) => {
    try {
      const { denialText, planNotes, neighborhood, projectType } = req.body;

      // Separate denial files from plan files by field name
      const denialFiles = req.files?.denialFiles || [];
      const planFiles = req.files?.planFiles || [];

      const systemPrompt = `You are PermitIQ, an expert Boston building permit and ZBA appeal strategist with deep knowledge of the Boston Zoning Code, 780 CMR, and ZBA procedures.

Analyze the ISD denial letter and any plans provided, then respond with EXACTLY these bold section headers:

**DENIAL ANALYSIS**
Break down every specific violation. For each: what was denied, the exact code section, and whether it is a dimensional variance, special permit, or procedural issue.

**CAN ANY VIOLATIONS BE CURED WITHOUT ZBA?**
For each violation: yes or no, and exactly what plan change would cure it. If all can be cured by redesign, say so clearly — no ZBA needed.

**ZBA APPEAL STRATEGY**
Full legal and tactical strategy: type of relief needed for each violation, strongest arguments under Massachusetts variance law, how to frame the hardship, community outreach strategy.

**STEP-BY-STEP ACTION PLAN**
Numbered steps from today through the ZBA hearing. Include the 45-day filing deadline from the refusal letter, fees ($150 flat for residential 3 units or fewer; $150 per violation for others), and permitsonline.boston.gov.

**DRAFT APPEAL LANGUAGE**
A complete paragraph the applicant can use verbatim in their ZBA filing.

**DOCUMENTS TO GATHER NOW**
Complete checklist specific to this denial — every document needed for a winning appeal.

**HEARING PREPARATION**
What to bring, who should appear, how to present, how to handle opposition.

**LIKELIHOOD AND RISKS**
Honest probability of success, what could go wrong, whether redesign before appealing is worth considering.`;

      const content = [];

      // Denial letter files
      if (denialFiles.length > 0) {
        for (const f of denialFiles) {
          if (f.mimetype.startsWith("image/")) {
            content.push({
              type: "image",
              source: { type: "base64", media_type: f.mimetype, data: f.buffer.toString("base64") },
            });
          } else {
            const txt = await extractFileText(f);
            content.push({
              type: "text",
              text: `--- ISD DENIAL LETTER: ${f.originalname} ---\n${txt || "(no extractable text)"}`,
            });
          }
        }
      }

      // Manual denial text
      if (denialText && denialText.trim()) {
        content.push({ type: "text", text: `--- DENIAL LETTER TEXT ---\n${denialText.trim()}` });
      }

      // Plans
      if (planFiles.length > 0) {
        for (const f of planFiles) {
          if (f.mimetype.startsWith("image/")) {
            content.push({
              type: "image",
              source: { type: "base64", media_type: f.mimetype, data: f.buffer.toString("base64") },
            });
          } else {
            const txt = await extractFileText(f);
            content.push({
              type: "text",
              text: `--- PLANS: ${f.originalname} ---\n${txt || "(no extractable text)"}`,
            });
          }
        }
      }

      if (planNotes && planNotes.trim()) {
        content.push({ type: "text", text: `--- PLAN NOTES ---\n${planNotes.trim()}` });
      }

      if (neighborhood) content.push({ type: "text", text: `Neighborhood: ${neighborhood}` });
      if (projectType) content.push({ type: "text", text: `Project type: ${projectType}` });

      if (!content.length && !denialText) {
        return res.status(400).json({ error: "Please upload your denial letter or paste the denial text." });
      }

      content.push({
        type: "text",
        text: "\nProvide a comprehensive action plan to successfully appeal this denial at the ZBA.",
      });

      const message = await client.messages.create({
        model: "claude-sonnet-4",
        max_tokens: 4096,
        system: systemPrompt,
        messages: [{ role: "user", content }],
      });

      const text = message.content
        .filter((b) => b.type === "text")
        .map((b) => b.text)
        .join("")
        .trim();

      res.json({ result: text });
    } catch (err) {
      console.error("analyze-denial error:", err);
      res.status(500).json({ error: err.message || "Analysis failed" });
    }
  }
);

// ── Serve React build in production ──────────────────────────────────────────
if (process.env.NODE_ENV === "production") {
  const buildPath = path.join(__dirname, "../client/build");
  app.use(express.static(buildPath));
  app.get("*", (req, res) => {
    res.sendFile(path.join(buildPath, "index.html"));
  });
}

app.listen(PORT, () => {
  console.log(`PermitIQ server running on port ${PORT}`);
});
